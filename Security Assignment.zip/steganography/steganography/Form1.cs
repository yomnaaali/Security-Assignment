using steganography.Helpers;

namespace steganography
{
    public partial class Form1 : Form
    {
        private SteganographyHelper stego = new SteganographyHelper();
        private Bitmap originalImage;

        public Form1()
        {
            InitializeComponent();
        }

        private void loadImageBtn_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();
            if (openFile.ShowDialog() == DialogResult.OK)
            {
                originalImage = new Bitmap(openFile.FileName);
                pictureBox1.Image = originalImage;
            }
        }

        private void encodeBtn_Click(object sender, EventArgs e)
        {
            if (originalImage != null && !string.IsNullOrEmpty(txtMessage.Text))
            {
                Bitmap encodedImage = stego.HideText(txtMessage.Text, originalImage);
                string fileName = $"hidden_image_{DateTime.Now:yyyyMMdd_HHmmss}.png";
                string savePath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\" + fileName;
                encodedImage.Save(savePath);


                MessageBox.Show("Text Hidden Successfully!");
            }
        }

        private void decodeBtn_Click(object sender, EventArgs e)
        {
            if (originalImage != null)
            {
                string text = stego.ExtractText(originalImage);
                MessageBox.Show("Hidden Text: " + text);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
